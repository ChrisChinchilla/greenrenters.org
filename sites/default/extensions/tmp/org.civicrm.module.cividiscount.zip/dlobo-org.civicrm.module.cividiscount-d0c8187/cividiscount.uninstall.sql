DROP TABLE IF EXISTS `cividiscount_track`;
DROP TABLE IF EXISTS `cividiscount_item`;
